﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VenusHR.Application.Common.Interfaces.SelfService;
using VenusHR.Core.Master;
using VenusHR.Infrastructure.Presistence;

namespace VenusHR.API.Controllers.SelfService
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnnualVacationRequestController : ControllerBase
    {
        private ApplicationDBContext _context;
        private readonly IAnnualVacationRequestService _AnnualVacationRequestService;
        public AnnualVacationRequestController(IAnnualVacationRequestService AnnualVacationRequestService, ApplicationDBContext Context)
        {
            _context = Context;
            _AnnualVacationRequestService = AnnualVacationRequestService;

        }

        [HttpGet, Route("GetAnnualVacsBalancesByEMP/{EmpID}/{ToDate}")]
        public ActionResult<Hrs_EmployeesVacation> GetEmpAnnualVacationRemainingBalanceByEmpCode(int EmpID, DateTime ToDate)
        {

            var Result = _AnnualVacationRequestService.GetAnnualVacsBalancesByEMP(EmpID, ToDate);
            return Ok(Result);
        }

        [HttpPost, Route("SaveAnnualVacationRequest")]
        public ActionResult<SS_VacationRequest> SaveAnnualVacationRequest( SS_VacationRequest Request)
        {
            object Result = _AnnualVacationRequestService.SaveAnnualVacationRequest( Request);
            return Ok(Result);
        }

        [HttpPost, Route("SaveAnnualVacationMedicalRequest")]
        public ActionResult<SS_VacationRequest> SaveAnnualVacationMedicalRequest(SS_VacationRequest Request)
        {
            object Result = _AnnualVacationRequestService.SaveAnnulavacationMedicalRequest(Request);
            return Ok(Result);
        }
        


        [HttpGet, Route("GetAnnualVacationRequestStatus/{RequestSerial}/{Lang}")]
        public ActionResult<Hrs_EmployeesVacation> GetAnnualVacationRequestStatus(int RequestSerial, int Lang)
        {

            var Result = _AnnualVacationRequestService.GetAnnualVacationRequestStatus(RequestSerial, Lang);
            return Ok(Result);
        }




        [HttpGet, Route("GetAnnualVacationRequestByID/{RequestSerial}/{Lang}")]

        public ActionResult<SS_VacationRequest> GetAnnualVacationRequestByID(int RequestSerial, int Lang)
        {
            var Result = _AnnualVacationRequestService.GetAnnualVacationRequestByID(RequestSerial,Lang);
            return Ok(Result);
        }
    }
}
