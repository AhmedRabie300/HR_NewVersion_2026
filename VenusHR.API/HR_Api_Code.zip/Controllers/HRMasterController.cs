﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.Metrics;
using VenusHR.Application.Common.Interfaces.HR_Master;
using VenusHR.Application.Common.Interfaces.SelfService;
using VenusHR.Core.Master;
using VenusHR.Infrastructure.Presistence;
using VenusHR.Infrastructure.Presistence.HRServices;
using VenusHR.Infrastructure.Presistence.SelfService;
using WorkFlow_EF;


namespace VenusHR.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HRMasterController : ControllerBase
    {
        private ApplicationDBContext _context;
        private readonly IHRMaster _HRMaster;
        public HRMasterController(IHRMaster HRMaster, ApplicationDBContext context)
        {
            _context = context;
            _HRMaster = HRMaster;
        }

        [HttpGet, Route("GetAllMasterData/{Lang}")]
        public ActionResult GetAllMasterData(int Lang)
        {
            var cities = (_HRMaster.GetAllCities(Lang) as GeneralOutputClass<object>)?.ResultObject;
            var nationalities = (_HRMaster.GetAllNationalities(Lang) as GeneralOutputClass<object>)?.ResultObject;
            var banks = (_HRMaster.GetAllBanks(Lang) as GeneralOutputClass<object>)?.ResultObject;
            var religions = (_HRMaster.GetAllReligions(Lang) as GeneralOutputClass<object>)?.ResultObject;
            var maritalStatuses = (_HRMaster.GetAllMaritalStatus(Lang) as GeneralOutputClass<object>)?.ResultObject;
            var bloodGroups = (_HRMaster.GetAllBloodGroups(Lang) as GeneralOutputClass<object>)?.ResultObject;
            var educations = (_HRMaster.GetAllEducations(Lang) as GeneralOutputClass<object>)?.ResultObject;

            // Combine all result objects into a single response object
            var data = new
            {
                cities,
                nationalities,
                banks,
                religions,
                maritalStatuses,
                bloodGroups,
                educations
            };

            return Ok(data);
        }

        [HttpGet, Route("GetAllCities/{Lang}")]
        public ActionResult<IMaster> GetAllCities(int Lang)
        {

            var Result = _HRMaster.GetAllCities(Lang);
            return Ok(Result);
        } 
        [HttpGet, Route("GetAllNationalities/{Lang}")]
        public ActionResult<IMaster> GetAllNationalities(int Lang)
        {

            var Result = _HRMaster.GetAllNationalities(Lang);
            return Ok(Result);
        }


        [HttpGet, Route("GetAllBanks/{Lang}")]
        public ActionResult<IMaster> GetAllBanks(int Lang)
        {

            var Result = _HRMaster.GetAllBanks(Lang);
            return Ok(Result);
        }

        [HttpGet, Route("GetAllReligions/{Lang}")]
        public ActionResult<IMaster> GetAllReligions(int Lang)
        {

            var Result = _HRMaster.GetAllReligions(Lang);
            return Ok(Result);
        } 
        
        
        [HttpGet, Route("GetAllMaritalStatus/{Lang}")]
        public ActionResult<IMaster> GetAllMaritalStatus(int Lang)
        {

            var Result = _HRMaster.GetAllMaritalStatus(Lang);
            return Ok(Result);
        }  
        [HttpGet, Route("GetAllBloodGroups/{Lang}")]
        public ActionResult<IMaster> GetAllBloodGroups(int Lang)
        {

            var Result = _HRMaster.GetAllBloodGroups(Lang);
            return Ok(Result);
        }      
        
        [HttpGet, Route("GetAllEducations/{Lang}")]
        public ActionResult<IMaster> GetAllEducations(int Lang)
        {

            var Result = _HRMaster.GetAllEducations(Lang);
            return Ok(Result);
        }

        [HttpPost, Route("SaveNewEmployeeForm")]
        public ActionResult<Hrs_NewEmployee> SaveNewEmployeeForm(Hrs_NewEmployee NewEmployee)
        {
            try
            {
                var result = _HRMaster.SaveNewEmployeeForm(NewEmployee) as GeneralOutputClass<object>;

                if (result.ErrorCode == 0)
                {
                    return BadRequest(result.ErrorMessage);
                }

                return Ok(result.ResultObject);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
